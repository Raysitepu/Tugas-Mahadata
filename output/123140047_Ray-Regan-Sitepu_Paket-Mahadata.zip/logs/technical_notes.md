# Catatan teknis aktual

- Panduan DOCX dibaca dari file yang diberikan pengguna; laporan akhir yang diminta panduan adalah PDF.
- Dataset workspace: 168 CSV, 8.542.826.421 byte, 167.932.474 baris data (pemindaian baris seluruh file).
- Python awal: 3.13. Pustaka PySpark, Matplotlib, ReportLab, dan pypdf belum tersedia.
- Lingkungan virtual dibuat di workspace; versi pustaka dipin di requirements.txt.
- Pemasangan pip awal tertahan pada dependensi build dengan penggunaan CPU tinggi. Pemasangan
  diulang menggunakan --isolated --no-cache-dir dan build dependency yang dipasang eksplisit;
  langkah metadata kemudian selesai. Akar masalah konfigurasi/cache pip belum dipastikan.
- Java awal: Oracle JDK 25.0.1; dokumentasi Spark 4.0.1 mendukung Java 17/21.
- JDK Temurin 21 portabel diunduh ke runtime workspace tanpa mengganti Java global.
- Unduhan JDK dengan Invoke-WebRequest awal gagal karena koneksi HTTPS ditutup.
  Pengunduhan ulang melalui urllib berhasil; SHA-256 diverifikasi dengan metadata Adoptium.
- Pemeriksaan RAM melalui CIM ditolak oleh izin OS; kapasitas RAM fisik tidak diklaim dalam laporan.
- Unduhan langsung PDF/HTML artikel via urllib mengembalikan halaman perantara, bukan artikel.
  File tersebut dibuang. Isi dan metadata artikel diperiksa melalui browser pencarian web di situs penerbit.
- Tabel 6 artikel diakses melalui hasil terindeks halaman SpringerOpen; angka pembanding menyebut cakupan sumber.
- Pengguna kemudian memberi repositori tujuan publik Raysitepu/Tugas-Mahadata;
  tautan tersebut dimasukkan ke laporan. Pengiriman LMS tidak dilakukan.
- Alur mentah menghasilkan seluruh metrik dalam 72,87 detik. Pipeline PowerShell Tee-Object
  melaporkan exit 1 setelah keluaran lengkap, dengan pesan Access denied pada cleanup.
  Tidak ada JVM Java tersisa pada pemeriksaan proses berikutnya. Konsistensi artefak diperiksa
  independen oleh verify_results.py, dan semuanya lulus; eksekusi model diulang tanpa pipeline Tee-Object.
- Rendering dengan pdftoppm MiKTeX gagal karena direktori log di luar workspace tidak dapat ditulis
  dan font Symbol tidak ditemukan. Render PDF dialihkan ke MuPDF pada lingkungan workspace.
- Semua sepuluh halaman PDF dirender dan diperiksa secara visual; halaman yang berubah diperiksa ulang.
- Struktur laporan kemudian disesuaikan dengan contoh DOCX yang diberikan pengguna:
  sampul formal, I-IV dan subbab bernomor, bagian 5 tautan kode, daftar pustaka,
  pernyataan penggunaan alat bantu, dan Lampiran A. Versi revisi berisi 11 halaman.
- Unggah household_coverage.csv ke repositori publik ditolak pemeriksaan persetujuan otomatis
  karena memuat ID meter dan informasi cakupan per rumah. Selanjutnya pengguna meminta
  seluruh unggahan dihentikan dan akan mengunggah sendiri. Tidak ada penulisan GitHub lanjutan.
  README saja sudah sempat diterbitkan pada cabang; blob berkas lain belum ditautkan ke cabang.
- ZIP untuk unggahan manual hanya memuat data agregat, tanpa cakupan per rumah atau daftar ID kohort;
  data asli dan keluaran rinci tetap tersedia lokal.
- Pemodelan dari agregat diulang dua kali pada folder terpisah dan keluar dengan kode 0.
  Metrik sama dalam toleransi 1e-12. Peringatan cleanup Access denied tidak menghalangi hasil;
  tidak ada proses Java tersisa setelah pengulangan. Perbaikan resolusi Python via PATH
  menghilangkan peringatan 'The system cannot find the path specified' pada launcher terakhir.
